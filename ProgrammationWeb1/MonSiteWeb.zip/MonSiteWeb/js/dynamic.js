function valeurDeMaVariable(nombre) {
    
    if(nombre == 5) {
        alert("La variable vaut 5");
    } else {
        alert("La valeur ne vaut pas 5");
        }
    }